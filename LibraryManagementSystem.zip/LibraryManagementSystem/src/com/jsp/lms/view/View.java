package com.jsp.lms.view;

import java.util.Scanner;

import com.jsp.lms.controller.Controller;
import com.jsp.lms.model.Book;
import com.jsp.lms.model.Library;

public class View {
	static private Library Library = new Library();

	public static Library getLibrary() {
		return Library;
	}

	public static void setLibrary(Library library) {
		Library = library;
	}

	static Scanner myInput = new Scanner(System.in);
	static Controller controller = new Controller();

	static {
		System.out.println("----WELCOME TO LMS----");
		System.out.println("Enter name of library: ");
		String libraryName = myInput.nextLine();
		Library.setLibraryName(libraryName);

		//
		System.out.println("Enter address of library: ");
		Library.setLibraryAddress(myInput.nextLine());

		System.out.println("Enter pincode: ");
		Library.setLibraryPincode(myInput.nextInt());
		myInput.nextLine();
	}

	public static void main(String[] args) {
//	System.out.println("name="+Library.getLibraryName());3
//	System.out.println("add="+Library.getLibraryAddress());
//	System.out.println("pincode="+Library.getLibraryPincode());

		do {
			System.out.println("Select option to perform");
			System.out.println("1.Add book\n2.Remove Book\n 3.Update book \n4.Get book \n 0.Exits");
			System.out.print("Enter digit respective desire option: ");
			byte userchoice = myInput.nextByte();
			myInput.nextLine();

			switch (userchoice) {
			case 0:
				myInput.close();
				System.out.println("-----EXIT-----");
				System.exit(0);
				break;
			case 1:
				Book book = new Book();
				controller.addBook(book);
				System.out.println("Enter book name");
				book.setBookName(myInput.nextLine());
				System.out.println("Enter book Author name");
				book.setBookAuthor(myInput.nextLine());
				System.out.println("Enter book price");
				book.setBookPrice(myInput.nextDouble());
				System.out.println("Book added successfully");

				break;
			case 2:
				System.out.println("Enter book name to remove");
				String bookToRemove = myInput.nextLine();// user inputs is taken and store in string 
				if (controller.removeBook(bookToRemove)) {
					System.out.println("Requested book has been removed");
				} else {
					System.out.println("Requested book does not exist");
				}
				break;
			case 3:
				System.out.println("Enter book name to update");
				Book bookExist = controller.getBook(myInput.nextLine());
				if (bookExist != null) {
					Book bookToUpdate=bookExist;
					System.out.println("what to update?");
					System.out.println("1.Book name \n 2.Author name \n 3.Book price");
					System.out.println("Enter digit respective to desired option");
					byte updateChoice = myInput.nextByte();
					myInput.nextLine();
					switch (updateChoice) {
					case 1:
                             System.out.println("Enter book name to update");
                       
                             bookToUpdate.setBookName(myInput.nextLine());
						break;
					case 2:
                           System.out.println("Enter author name to update");
                           bookToUpdate.setBookAuthor(myInput.nextLine());
						break;
					case 3:
                          System.out.println("Enter book price");
                          bookToUpdate.setBookPrice(myInput.nextDouble());
                         
                          bookToUpdate.setBookPrice(myInput.nextDouble());
                          myInput.nextLine();
						break;

					default:
						System.out.println("please enter valid option");
						break;
						
					}
				}
				break;
			case 4:
				System.out.println("enter a book name you are looking for");
				Book fetchBook = controller.getBook(myInput.nextLine());
				if (fetchBook != null) {
					System.out.println("books is available");
					System.out.println("details");
					System.out.println(fetchBook);
				} else {
					System.out.println("book is not available");
				}

				break;

			default:
				System.out.println("invalid option");
				break;
			}

		} while (true);
	}

}
